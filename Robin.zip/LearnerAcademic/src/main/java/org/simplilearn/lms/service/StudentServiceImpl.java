package org.simplilearn.lms.service;

import java.util.List;

import org.simplilearn.lms.DAO.StudentDao;
import org.simplilearn.lms.DAO.StudentDaoImpl;
import org.simplilearn.lms.entities.Student;

public class StudentServiceImpl implements StudentServices {
	private StudentDao dao=new StudentDaoImpl();

	@Override
	public void addStudent(Student student) {
		dao.insert(student);
		
	}

	@Override
	public void deleteStudent(Student student) {
		dao.delete(student);
		
	}

	@Override
	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Student> getStudents() {
		// TODO Auto-generated method stub
		return dao.getAll();
	}

}
