package org.simplilearn.lms.service;

import java.util.List;

import org.simplilearn.lms.DAO.StudentDao;
import org.simplilearn.lms.DAO.StudentDaoImpl;
import org.simplilearn.lms.DAO.SubjectDao;
import org.simplilearn.lms.DAO.SubjectDaoImpl;
import org.simplilearn.lms.entities.Subject;

public class SubjectServiceImpl implements SubjectServices {
	private SubjectDao dao=new SubjectDaoImpl();
	@Override
	public void addSubject(Subject subject) {
		dao.insert(subject);
		
	}

	@Override
	public List<Subject> getSubjects() {
		// TODO Auto-generated method stub
		return null;
	}

}
