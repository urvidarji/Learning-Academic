package org.simplilearn.lms.service;

import org.simplilearn.lms.entities.User;

public interface SavedUserLogin {
	static void insert(User user) {
		// TODO Auto-generated method stub
		
	}
}
