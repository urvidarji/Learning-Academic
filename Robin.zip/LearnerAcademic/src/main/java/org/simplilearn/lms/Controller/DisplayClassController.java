package org.simplilearn.lms.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.simplilearn.lms.entities.AcademicClass;
import org.simplilearn.lms.entities.Subject;
import org.simplilearn.lms.service.AcademicService;
import org.simplilearn.lms.service.AcademicServiceImpl;
import org.simplilearn.lms.service.SubjectServices;
import org.simplilearn.lms.service.SubjectServicesImpl;

public class DisplayClassController extends HttpServlet {
	private AcademicService academicservice=new AcademicServiceImpl();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<AcademicClass> academicclass=academicservice.getClasses();
		req.setAttribute("academicclass",academicclass);
		RequestDispatcher rd=req.getRequestDispatcher("DisplayClass.jsp");
		rd.forward(req, resp);
	}

}
